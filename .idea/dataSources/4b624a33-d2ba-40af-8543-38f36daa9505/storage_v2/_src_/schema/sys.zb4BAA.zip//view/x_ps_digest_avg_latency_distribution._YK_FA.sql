CREATE VIEW `x$ps_digest_avg_latency_distribution` AS
  SELECT
    count(0)                                                                                          AS `cnt`,
    round((`performance_schema`.`events_statements_summary_by_digest`.`AVG_TIMER_WAIT` / 1000000), 0) AS `avg_us`
  FROM `performance_schema`.`events_statements_summary_by_digest`
  GROUP BY `avg_us`;

