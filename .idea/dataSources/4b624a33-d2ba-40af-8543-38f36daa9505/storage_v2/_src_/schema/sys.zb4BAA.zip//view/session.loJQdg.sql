CREATE VIEW session AS
  SELECT
    `processlist`.`thd_id`                 AS `thd_id`,
    `processlist`.`conn_id`                AS `conn_id`,
    `processlist`.`user`                   AS `user`,
    `processlist`.`db`                     AS `db`,
    `processlist`.`command`                AS `command`,
    `processlist`.`state`                  AS `state`,
    `processlist`.`time`                   AS `time`,
    `processlist`.`current_statement`      AS `current_statement`,
    `processlist`.`statement_latency`      AS `statement_latency`,
    `processlist`.`progress`               AS `progress`,
    `processlist`.`lock_latency`           AS `lock_latency`,
    `processlist`.`rows_examined`          AS `rows_examined`,
    `processlist`.`rows_sent`              AS `rows_sent`,
    `processlist`.`rows_affected`          AS `rows_affected`,
    `processlist`.`tmp_tables`             AS `tmp_tables`,
    `processlist`.`tmp_disk_tables`        AS `tmp_disk_tables`,
    `processlist`.`full_scan`              AS `full_scan`,
    `processlist`.`last_statement`         AS `last_statement`,
    `processlist`.`last_statement_latency` AS `last_statement_latency`,
    `processlist`.`current_memory`         AS `current_memory`,
    `processlist`.`last_wait`              AS `last_wait`,
    `processlist`.`last_wait_latency`      AS `last_wait_latency`,
    `processlist`.`source`                 AS `source`,
    `processlist`.`trx_latency`            AS `trx_latency`,
    `processlist`.`trx_state`              AS `trx_state`,
    `processlist`.`trx_autocommit`         AS `trx_autocommit`,
    `processlist`.`pid`                    AS `pid`,
    `processlist`.`program_name`           AS `program_name`
  FROM `sys`.`processlist`
  WHERE ((`processlist`.`conn_id` IS NOT NULL) AND (`processlist`.`command` <> 'Daemon'));

